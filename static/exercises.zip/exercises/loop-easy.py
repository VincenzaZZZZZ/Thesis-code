n = int(input("Please enter a positive number: "))
result = 0

for i in range(n):
    result += i

print(result)