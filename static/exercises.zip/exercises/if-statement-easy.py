user_age = int(input("Enter your age: "))

if user_age >= 18:
    print("You are an adult.")
print("Access granted.")
